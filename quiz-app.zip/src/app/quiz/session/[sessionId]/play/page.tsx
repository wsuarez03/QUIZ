"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { db } from "@/lib/firebase";
import { collection, doc, onSnapshot } from "firebase/firestore";
import { Navbar } from "@/components/Navbar";

export default function PlaySessionPage() {

  const params = useParams();
  const search = useSearchParams();
  const router = useRouter();

  const sessionId = params.sessionId as string;
  const playerName = search.get("name") || "";

  const [quiz, setQuiz] = useState<any>(null);
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);

  const [correct, setCorrect] = useState<boolean | null>(null);
  const [time,setTime] = useState(20);

  async function sendAnswer(index: number) {

    if (answered) return;

    setSelected(index);
    setAnswered(true);

    const res = await fetch("/api/answers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId,
        playerName,
        questionIndex: session.currentQuestion,
        answerIndex: index
      })
    });

    const result = await res.json();

    setCorrect(result.correct);
  }

  useEffect(() => {

    if (!sessionId) return;

    setLoading(true);

    let unsubQuiz = () => {};
    let unsubQuestions = () => {};

    const unsubSession = onSnapshot(
      doc(db, "game_sessions", sessionId),
      (snap) => {

        if (!snap.exists()) {
          setError("Sesión no encontrada");
          setLoading(false);
          return;
        }

        const sessionData = snap.data();
        setSession(sessionData);

        if (!sessionData?.quizId) {
          setError("Sesión configurada incorrectamente");
          setLoading(false);
          return;
        }

        const quizRef = doc(db, "quizzes", sessionData.quizId);

        unsubQuiz();
        unsubQuestions();

        unsubQuiz = onSnapshot(
          quizRef,
          (quizSnap) => {

            if (!quizSnap.exists()) {
              setError("Quiz no encontrado");
              setLoading(false);
              return;
            }

            const quizData = quizSnap.data();

            if (Array.isArray(quizData.questions) && quizData.questions.length > 0) {
              setQuiz(quizData);
              setLoading(false);
              return;
            }

            setQuiz({ ...quizData, questions: [] });

            const questionsRef = collection(
              db,
              "quizzes",
              sessionData.quizId,
              "questions"
            );

            unsubQuestions = onSnapshot(
              questionsRef,
              (questionsSnap) => {

                const questions = questionsSnap.docs.map((doc) => ({
                  id: doc.id,
                  ...doc.data(),
                }));

                setQuiz((prev: any) => ({ ...prev, questions }));

                setLoading(false);
              }
            );
          }
        );
      }
    );

    return () => {
      unsubSession();
      unsubQuiz();
      unsubQuestions();
    };

  }, [sessionId]);

  // reset cuando cambia pregunta
  useEffect(() => {

    setSelected(null);
    setAnswered(false);
    setCorrect(null);
    setTime(20);

  }, [session?.currentQuestion]);

useEffect(() => {

 if(time <= 0) return;

 const timer = setInterval(()=>{
   setTime(t => t - 1);
 },1000);

 return () => clearInterval(timer);

},[time]);

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex items-center justify-center">
          Cargando...
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex items-center justify-center text-red-500">
          {error}
        </div>
      </>
    );
  }

  const question = quiz?.questions?.[session?.currentQuestion ?? 0] || null;

  const questionText = question?.text || question?.question || "";
  const options = question?.options || question?.answers || [];

  if (!quiz || !question) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex flex-col items-center justify-center gap-4">
          <div className="text-xl font-semibold">
            Esperando pregunta...
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="min-h-screen p-8">

        <h1 className="text-2xl font-bold mb-4">
          {quiz.title}
        </h1>

        <h2 className="text-xl mb-2">
          Pregunta {session.currentQuestion + 1}
        </h2>
        
        <div className="text-3xl font-bold mb-4">
        ⏱ {time}
        </div>

        <div className="text-lg mb-6">
          {questionText}
        </div>

        <div className="grid grid-cols-2 gap-4">

          {options.map((opt: string, i: number) => (

            <button
              key={i}
              disabled={answered}
              onClick={() => sendAnswer(i)}
              className={`p-4 rounded text-white font-bold transition
              ${selected === i ? "bg-green-500" : "bg-blue-500 hover:bg-blue-600"}
              ${answered && selected !== i ? "opacity-50" : ""}`}
            >
              {opt}
            </button>

          ))}

        </div>

        {correct !== null && (
          <div className="mt-6 text-xl font-bold">
            {correct ? "✅ Correcto" : "❌ Incorrecto"}
          </div>
        )}

        <div className="mt-8 text-gray-500">
          Jugador: {playerName}
        </div>

      </main>
    </>
  );
}