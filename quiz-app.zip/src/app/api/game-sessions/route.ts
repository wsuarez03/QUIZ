import { collection, addDoc, serverTimestamp, getDoc, doc, query, where, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { NextResponse } from "next/server"

function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

export async function POST(req: Request) {
  try {

    const body = await req.json()
    const quizId = body?.quizId
    console.log("QUIZ ID RECIBIDO:", quizId)

    if (!quizId) {
      return NextResponse.json(
        { error: "quizId requerido" },
        { status: 400 }
      )
    }

    // 1️⃣ validar que el quiz exista
    const quizRef = doc(db, "quizzes", quizId)
    const quizSnap = await getDoc(quizRef)

    if (!quizSnap.exists()) {
      return NextResponse.json(
        { error: "El quiz no existe" },
        { status: 404 }
      )
    }

    // 2️⃣ generar código único
    let code = generateCode()
    let codeExists = true

    while (codeExists) {
      const q = query(
        collection(db, "game_sessions"),
        where("code", "==", code)
      )

      const snapshot = await getDocs(q)

      if (snapshot.empty) {
        codeExists = false
      } else {
        code = generateCode()
      }
    }

    // 3️⃣ crear sesión
    const sessionRef = await addDoc(
      collection(db, "game_sessions"),
      {
        quizId,
        code,
        status: "waiting",
        currentQuestion: 0,
        createdAt: serverTimestamp()
      }
    )

    return NextResponse.json({
      success: true,
      sessionId: sessionRef.id,
      code
    })

  } catch (error) {

    console.error("Error creando sesión:", error)

    return NextResponse.json(
      { error: "Error creando sesión" },
      { status: 500 }
    )

  }
}