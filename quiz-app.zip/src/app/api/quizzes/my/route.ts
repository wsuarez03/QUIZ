import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { adminDbInstance, isConfigured } from '@/lib/firebaseAdmin';
import { mockQuizzes } from '@/lib/mockData';
// reading via admin to bypass security rules (server-side)
import { collection, query, where, getDocs } from 'firebase/firestore';
import { QueryDocumentSnapshot, DocumentData } from 'firebase-admin/firestore';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    // Validar que session.user.id exista
    if (!session.user.id) {
      console.error('Session user ID is undefined');
      return NextResponse.json([], { status: 200 });
    }

    // If Firebase Admin is not configured, use mock data
    if (!isConfigured) {
      const userQuizzes = mockQuizzes.filter(
        (quiz) => quiz.createdBy === session.user.id
      );
      return NextResponse.json(userQuizzes, { status: 200 });
    }

    // use admin SDK for secure server-side access
    let quizzes: any[] = [];

    try {
      const querySnapshot = await adminDbInstance
        .collection('quizzes')
        .where('createdBy', '==', session.user.id)
        .get();

      quizzes = querySnapshot.docs.map((doc: QueryDocumentSnapshot<DocumentData>) => {
        const data = doc.data();

        return {
          id: doc.id,
          ...data,
          questions: data.questions ?? [],
          createdAt: data.createdAt?.toDate?.() || new Date(),
        };
      });

    } catch (err) {
      console.error('Error querying user quizzes from Firestore:', err);
      // leave quizzes as empty array to avoid crashing UI
    }

    return NextResponse.json(quizzes, { status: 200 });

  } catch (error) {
    console.error('Error fetching quizzes:', error);

    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}