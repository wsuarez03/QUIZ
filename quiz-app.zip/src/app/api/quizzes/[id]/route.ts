import { NextRequest, NextResponse } from 'next/server';
import { adminDbInstance, isConfigured } from '@/lib/firebaseAdmin';
import { mockQuizzes, mockQuestions } from '@/lib/mockData';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
// server-side operations use adminDb to bypass security rules

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: quizId } = await params;

    // If Firebase Admin is not configured, use mock data
    if (!isConfigured) {
      const quiz = mockQuizzes.find((q) => q.id === quizId);
      if (!quiz) {
        return NextResponse.json(
          { message: 'Quiz not found' },
          { status: 404 }
        );
      }
      // Adjuntar preguntas desde mockQuestions (type assertion para evitar error TS)
      const questions = (mockQuestions as Record<string, any[]>)[quizId] || [];
      return NextResponse.json({ ...quiz, questions }, { status: 200 });
    }

    // adminDb is used on server to bypass security rules
    const quizSnapshot = await adminDbInstance
      .collection('quizzes')
      .doc(quizId)
      .get();

    if (!quizSnapshot.exists) {
      return NextResponse.json(
        { message: 'Quiz not found' },
        { status: 404 }
      );
    }

    const quizData = quizSnapshot.data();

    // Fetch questions for this quiz.
    // Some setups store questions inside the quiz document (quizData.questions),
    // while newer versions store them in a subcollection.
    let questions: any[] = Array.isArray(quizData?.questions) ? quizData.questions : [];

    if (!questions.length) {
      try {
        const questionsSnapshot = await adminDbInstance
          .collection('quizzes')
          .doc(quizId)
          .collection('questions')
          .get();

        questions = questionsSnapshot.docs.map((doc: any) => ({
          id: doc.id,
          ...doc.data(),
        }));
      } catch (error) {
        console.log('Note: Could not fetch questions from subcollection:', error);
      }
    }

    return NextResponse.json(
      {
        id: quizId,
        ...quizData,
        questions: questions,
        createdAt: quizData.createdAt?.toDate?.() || new Date(),
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error fetching quiz:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: quizId } = await params;
    
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    // If Firebase Admin is not configured, mock data cannot be deleted
    if (!isConfigured) {
      return NextResponse.json(
        { message: 'Cannot delete mock data in development mode' },
        { status: 403 }
      );
    }

    const quizSnapshot = await adminDbInstance
      .collection('quizzes')
      .doc(quizId)
      .get();

    if (!quizSnapshot.exists) {
      return NextResponse.json(
        { message: 'Quiz not found' },
        { status: 404 }
      );
    }

    const quizData = quizSnapshot.data();

    // Check if user is the creator
    if (quizData.createdBy !== session.user.id) {
      return NextResponse.json(
        { message: 'Not authorized to delete this quiz' },
        { status: 403 }
      );
    }

    await adminDbInstance.collection('quizzes').doc(quizId).delete();

    return NextResponse.json(
      { message: 'Quiz deleted successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error deleting quiz:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
