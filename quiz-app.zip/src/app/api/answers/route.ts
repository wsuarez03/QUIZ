import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";

import {
  addDoc,
  collection,
  getDoc,
  doc,
  updateDoc,
  increment
} from "firebase/firestore";

export async function POST(req: NextRequest) {

  try {

    const { sessionId, playerName, questionIndex, answerIndex } =
      await req.json();

    const sessionSnap = await getDoc(
      doc(db, "game_sessions", sessionId)
    );

    if (!sessionSnap.exists()) {
      return NextResponse.json(
        { error: "session not found" },
        { status: 404 }
      );
    }

    const session = sessionSnap.data();

    const quizSnap = await getDoc(
      doc(db, "quizzes", session.quizId)
    );

    if (!quizSnap.exists()) {
      return NextResponse.json(
        { error: "quiz not found" },
        { status: 404 }
      );
    }

    const quiz = quizSnap.data();

    const question = quiz.questions?.[questionIndex];

    if (!question) {
      return NextResponse.json(
        { error: "question not found" },
        { status: 400 }
      );
    }

    // 🔧 detectar respuesta correcta
    let correctIndex = -1;

    if (typeof question.correctAnswerIndex === "number") {
      correctIndex = question.correctAnswerIndex;
    }
    else if (typeof question.correct === "number") {
      correctIndex = question.correct;
    }
    else if (question.correctAnswer) {
      correctIndex = question.options?.findIndex(
        (o: string) =>
         o.trim().toLowerCase() ===
         question.correctAnswer.trim().toLowerCase()
      );
    }

    const correct = Number(answerIndex) === Number(correctIndex);

    // score
    let score = 0;

    if (correct) {

      const now = Date.now();
      const start = session.questionStartTime || now;

      const elapsed = now - start;

      const maxTime = 15000;

      const timeBonus = Math.max(0, maxTime - elapsed);

      score = 500 + Math.floor(timeBonus / 20);

    }

    // guardar respuesta
    await addDoc(collection(db, "answers"), {
      sessionId,
      playerName,
      questionIndex,
      answerIndex,
      correct,
      score,
      createdAt: Date.now()
    });

    // actualizar jugador
    const playerRef = doc(
      db,
      "game_sessions",
      sessionId,
      "players",
      playerName
    );

    await updateDoc(playerRef, {
      score: increment(score),
      correctAnswers: correct ? increment(1) : increment(0)
    });

    return NextResponse.json({ success: true });

  } catch (e) {

    console.error(e);

    return NextResponse.json(
      { error: "server error" },
      { status: 500 }
    );

  }

}