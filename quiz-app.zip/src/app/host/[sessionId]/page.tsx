"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"

import { db } from "@/lib/firebase"

import {
  doc,
  updateDoc,
  onSnapshot,
  collection
} from "firebase/firestore"

import { Button } from "@/components/Button"
import { Navbar } from "@/components/Navbar"
import { Leaderboard } from "@/components/Leaderboard"

export default function HostPage() {

  const params = useParams()
  const sessionId = params?.sessionId as string

  const [session, setSession] = useState<any>(null)
  const [quiz, setQuiz] = useState<any>(null)
  const [players, setPlayers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  // 🔹 Escuchar sesión en tiempo real
  useEffect(() => {

    if (!sessionId) return

    const sessionRef = doc(db, "game_sessions", sessionId)

    const unsubscribe = onSnapshot(sessionRef, (snap) => {

      const data = snap.data()
      if (!data) return

      setSession({
        id: snap.id,
        ...data
      })

      setLoading(false)

    })

    return () => unsubscribe()

  }, [sessionId])


  // 🔹 Cargar quiz
  useEffect(() => {

    if (!session?.quizId) return

    const loadQuiz = async () => {

      const res = await fetch(`/api/quizzes/${session.quizId}`)
      const q = await res.json()

      setQuiz(q)

    }

    loadQuiz()

  }, [session?.quizId])


  // 🔹 Escuchar jugadores
  useEffect(() => {

    if (!sessionId) return

    const playersRef = collection(
      db,
      "game_sessions",
      sessionId,
      "players"
    )

    const unsubscribe = onSnapshot(playersRef, (snapshot) => {

      const list: any[] = []

      snapshot.forEach((doc) => {

        list.push({
          id: doc.id,
          ...doc.data()
        })

      })

      setPlayers(list)

    })

    return () => unsubscribe()

  }, [sessionId])


  // 🔹 Iniciar juego
  const startGame = async () => {

    const ref = doc(db, "game_sessions", sessionId)

    await updateDoc(ref, {
      status: "playing",
      currentQuestion: 0
    })

  }


  // 🔹 Siguiente pregunta manual
  const nextQuestion = async () => {

    if (!quiz) return

    const isLast =
      session.currentQuestion >= quiz.questions.length - 1

    if (isLast) {

      const ref = doc(db, "game_sessions", sessionId)

      await updateDoc(ref, {
        status: "finished"
      })

      return
    }

    const ref = doc(db, "game_sessions", sessionId)

    await updateDoc(ref, {
      currentQuestion: session.currentQuestion + 1
    })

  }


  // 🔹 TEMPORIZADOR AUTOMÁTICO
  useEffect(() => {

    if (!session || !quiz) return
    if (session.status !== "playing") return

    const isLast =
      session.currentQuestion >= quiz.questions.length - 1

    if (isLast) return

    const timer = setTimeout(() => {

      nextQuestion()

    }, 20000) // 20 segundos

    return () => clearTimeout(timer)

  }, [session?.currentQuestion, session?.status, quiz])


  if (loading) {

    return (
      <>
        <Navbar />
        <div className="min-h-screen flex items-center justify-center">
          Cargando sesión...
        </div>
      </>
    )

  }

  if (!session) {

    return (
      <>
        <Navbar />
        <div className="min-h-screen flex items-center justify-center">
          Sesión no encontrada
        </div>
      </>
    )

  }

  const question =
    quiz?.questions?.[session.currentQuestion]


  return (
    <>
      <Navbar />

      <main className="min-h-screen p-8 bg-white text-black">

        {/* LOBBY */}

        {session.status === "waiting" && (

          <div className="text-center">

            <h1 className="text-4xl font-bold mb-6">
              {quiz?.title}
            </h1>

            <div className="text-6xl font-bold bg-purple-600 text-white p-6 rounded-lg inline-block mb-4">
              {session.code}
            </div>

            <p className="mb-4">
              Jugadores conectados: {players.length}
            </p>

            <Button onClick={startGame}>
              Iniciar juego
            </Button>

            <div className="mt-8 space-y-2">

              {players.map((p) => (

                <div
                  key={p.id}
                  className="bg-gray-100 p-3 rounded"
                >
                  {p.name}
                </div>

              ))}

            </div>

          </div>

        )}


        {/* JUEGO */}

        {session.status === "playing" && question && (

          <div className="max-w-3xl mx-auto text-center">

            <h2 className="text-2xl mb-4">
              Pregunta {session.currentQuestion + 1}
            </h2>

            <h1 className="text-3xl font-bold mb-8">
              {question.text}
            </h1>

            <div className="grid grid-cols-2 gap-4 mb-8">

              {question.options.map((opt: string, i: number) => (

                <div
                  key={i}
                  className="p-4 bg-gray-100 rounded"
                >
                  {opt}
                </div>

              ))}

            </div>

            <Button onClick={nextQuestion}>
              Siguiente pregunta
            </Button>

            <div className="mt-10">

              <Leaderboard
                entries={players
                  .sort((a, b) => (b.score ?? 0) - (a.score ?? 0))
                  .map((p, idx) => ({
                    rank: idx + 1,
                    playerId: p.id,
                    playerName: p.name,
                    score: p.score ?? 0,
                    correctAnswers: p.correctAnswers ?? 0,
                    accuracy: 0
                  }))
                }
                title="Tabla de posiciones"
              />

            </div>

          </div>

        )}

      </main>

    </>
  )
}